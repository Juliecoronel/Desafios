const pastas = ["sorrentinos", "raviolis", "ñoquis"]
const copiaPastas = [...pastas, "fusilli", "rigatoni", "spaghetti", "fideos", "lasagna"]

const recorrerPastas = copiaPastas.map(pastas => console.log(pastas))
