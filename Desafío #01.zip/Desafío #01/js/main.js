class Cantante {
    static id = 0;
  
    constructor(nombre, edad, nacimiento, estatura, genero) {
      this.id = Cantante.id++;
      this.nombre = nombre;
      this.edad = edad;
      this.nacimiento = nacimiento;
      this.estatura = estatura;
      this.genero = genero;
    }
  }
  
  const cantante1 = new Cantante('Shakira Isabel Mebarak Ripoll', '46 años', '2 de febrero de 1977', '1,57 m', 'Pop, reguetón, urbano, latino');
  const cantante2 = new Cantante('Martina Stoessel', '26 años', '21 de marzo de 1997', '1.65 m', 'Pop, reguetón');
  const cantante3 = new Cantante('María de los Ángeles Becerra', '23 años', '12 de febrero de 2000', '1,55 m', 'Urbano latino, pop');
  const cantante4 = new Cantante('Nicole Denise Cucco', '22 años', '25 de agosto de 2000', '1.45 m', 'Pop, hip hop, reguetón, urbano latino');
  const cantante5 = new Cantante('Aubrey Drake Graham', '36 años', '24 de octubre de 1986', '1,82 m', 'Hip hop, rap, pop, trap');
  const cantante6 = new Cantante('Aurora Aksnes', '26 años', '15 de junio de 1996', '1,60 m', 'Pop, rock');
  const cantante7 = new Cantante('John Francis Bongiovi Jr.', '61 años', '2 de marzo de 1962', '1.75 m', 'Rock, J-Pop');
  
  const cantantes = [
    cantante1,
    cantante2,
    cantante3,
    cantante4,
    cantante5,
    cantante6,
    cantante7,
  ];
  
  console.log(cantantes);
  
  const listaCantante = (cantantes) => {
    cantantes.forEach((cantante) => {
    let body = document.querySelector('body')
    let div = document.createElement('div') 

      div.innerHTML = `
             <li><b>Nombre:</b> ${cantante.nombre}</li>
             <li><b>Edad:</b> ${cantante.edad}</li>
             <li><b>Nacimiento:</b> ${cantante.nacimiento}</li>
             <li><b>Estatura:</b> ${cantante.estatura}</li>
             <li><b>Género musical:</b> ${cantante.genero}</li>`

     body.appendChild(div)

      let boton = document.createElement('button');
      boton.innerHTML = cantante.id;
      boton.innerHTML = `Contratar`

     div.appendChild(boton)
    });
  };
  
  listaCantante(cantantes);
 
  const json = JSON.stringify(cantantes);
  console.log(cantantes);
  console.log(json);