let formularioPost = document.getElementById("formularioPost")

formularioPost.addEventListener("submit", submitForm)

function submitForm(e) {
    e.preventDefault();
    let formNombre = document.getElementById("formNombre").value;
    let formEmail = document.getElementById("formEmail").value;
    let formTelefono = document.getElementById("formTelefono").value;
    let formSitio = document.getElementById("formSitio").value;
    let formAsunto = document.getElementById("formAsunto").value;
    let formMensaje = document.getElementById("formMensaje").value;
  
    fetch("https://jsonplaceholder.typicode.com/posts", {
      method: "POST",
        body: JSON.stringify({
        nombre: formNombre,
        email: formEmail,
        telefono: formTelefono,
        sitio: formSitio,
        asunto: formAsunto,
        mensaje: formMensaje,
      }),
      headers: {
        "Content-type": "application/json",
      },
    })
      .then((response) => response.json())
      .then ((data) => {
        console.log(data);
        const textoForm = document.getElementById("textoForm");
        textoForm.innerHTML = `<p>${data.nombre}</p><p>${data.email}</p><p>${data.telefono}</p><p>${data.sitio}</p><p>${data.asunto}</p><p>${data.mensaje}</p>`;
      })
      .catch((e) => console.log("Ha ocurrido un error, intenta de nuevo"));
  }

